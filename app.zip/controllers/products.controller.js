const db = require("../models");
const Product = db.products;

exports.create = (req, res) => {
  // Create Database
    const product = new Product({
    id: req.body.id
  });

  // Save Database 
  Product.findOne({id: req.body.id}, (err, result) =>
  {
     if(err) 
     {
        res.status(500).send("500 Internal Server Error"); 
        return; 
     }
     if(!result) 
     {
      product
     .save(product)
     .then(data => {
       res.send(data);
     })
     .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Tutorial."
           });
        });
     }
     else {
        throw err; 
     }
  });
};


exports.findAll = (req, res) => {
  const userid = req.query.userid;
  var condition = userid ? { userid: { $regex: new RegExp(userid), $options: "i" } } : {};

  Product.find(condition)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Error"
      });
    });
};


exports.findOne = (req, res) => {
   Product.findOne({models: req.params.userid}, (err, result) =>
         {
            if(err) throw err;
            var data = result;
            res.send(data);
         }
      );
};

