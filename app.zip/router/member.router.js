module.exports = app => {
  const member = require("../controllers/member.controller.js");
  const products = require("../controllers/products.controllers.js");
  //const authJwt = require("../controllers/authJwt.js"); 
  var router = require("express").Router();
  
  router.post("/create", member.create);

  router.post("/loginuser", member.Loginuser);

  //router.get("/loginuser/admin", [authJwt.vertifyToken, authJwt.isAdmin], member.adminBoard); 

  router.get("/findall", member.findAll);

  router.get("/:userid", member.findOne);
    
  router.post("/:userid", member.update);
   
  router.post("/access/:userid", member.updateAccess);

  router.post("/hours/:userid", member.updateHours);
 
  router.delete("/:userid", member.delete);
  
  app.use("/api/member", router);

  app.use("/api/products", router1);

  router1.post("/find", products.find);
};
