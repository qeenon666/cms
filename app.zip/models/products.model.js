module.exports = mongoose => {
  var schema = mongoose.Schema(
  {  
    id: Number,
    model: String,
    manufacture: String,
    modelYear: Number,
    mileage: Number,
    description: String,
    color: String,
    price: Number,
    condition: Number,
    status: Number,
    VINCode: String
  } 
   ,{
    timestamps: true
});
  schema.method("toJSON", function() {
    const { __v, _id, ...object } = this.toObject();
    return object;
  });

  const products = mongoose.model("products", schema);
    return products;
};

