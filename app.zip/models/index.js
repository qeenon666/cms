
const mongoose = require("mongoose");
var MongoClient = mongoose.Promise = global.Promise;

var url = "mongodb://localhost:27017/product1"
const db={};
db.mongoose = mongoose;
db.url = url;
db.member = require("./member.model.js")(mongoose);
db.login = require("./login.model.js")(mongoose);
db.products = require("./products.model.js")(mongoose);

module.exports = db; 

